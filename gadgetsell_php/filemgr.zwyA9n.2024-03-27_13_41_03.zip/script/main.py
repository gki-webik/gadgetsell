import requests                    
from bs4 import BeautifulSoup
import time
import json
import pymysql


user = 'Mozilla/5.0 (compatible; U; ABrowse 0.6; Syllable) AppleWebKit/420+ (KHTML, like Gecko)'   
header = {
          'User-Agent': user,
          'Accept-Encoding':'gzip, deflate, br',
          'Accept-Language':'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
          'Content-Type':'text/plain'
          }

colors = { 
        '"000000"': 'Black',
        '"f9f9f9"': 'White',
        '"93dc68"': 'Green',
        '"004524"': 'Green',
        '"056ba9"': 'Blue',
        '"a561aa"': 'Purple',
        '"f47578"': 'Pink',
        '"41518d"': 'Blue',
        '"eae680"': 'Yellow',
        '"e2cbbb"': 'Natural',
        '"d5c5b3"': 'Gold',
        '"7a6f80"': 'Deep purple',
        '"c1c1c1"': 'Silver',
        '"fc0505"': 'Red',
        '828185': 'Gray',
        '808000': 'Olive',
        '"baadb6"': 'Violet',
        '"ff7a04"': 'Orange',
    }
dict_translate = {'А': 'A','а': 'a','Б': 'B','б': 'b','В': 'V','в': 'v','Г': 'G','г': 'g','Д': 'D','д': 'd','Е': 'E','е': 'e','Ё': 'E','ё': 'e','Ж': 'Zh','ж': 'zh','З': 'Z','з': 'z','И': 'I','и': 'i','Й': 'J','й': 'j','К': 'K','к': 'k','Л': 'L','л': 'l','М': 'M','м': 'm','Н': 'N','н': 'n','О': 'O','о': 'o','П': 'P','п': 'p','Р': 'R','р': 'r','С': 'S','с': 's','Т': 'T','т': 't','У': 'U','у': 'u','Ф': 'F','ф': 'f','Х': 'H','х': 'h','Ц': 'C','ц': 'c','Ч': 'Ch','ч': 'ch','Ш': 'Sh','ш': 'sh','Щ': 'Shch','щ': 'shch','Э': 'E','э': 'e','Ю': 'Yu','ю': 'yu','Я': 'Ya','я': 'ya','Ы': 'Y','ы': 'y','ъ': '','ь': '',}

def main(url):
    
    response = requests.get(url = url, headers = header).text
    soup = BeautifulSoup(response, 'html.parser')
    # Определяем количество страниц в категории
    try:
        pages = soup.find('div', class_="pagination_catalog").find('div', class_="catalog-s-p").find('div', class_="wrap_pagination").find('ul', class_="pagination").find_all('li')[-2].find('a').get('href').rpartition('=')
        print(pages[0])
        print(pages[1])
    except:
        pass
    
    try:
        n_pages = int(pages[2])
    except:
        n_pages = 1
    #print(n_pages)
    # Определяем адреса страниц
    j = 1
    r = 2
    while j < n_pages + 1:
        time.sleep(10)
        #print(i)
        try:
            url_page = f"https://store77.net{pages[0]}{pages[1]}{j}"
            #print(url_page)
        except:
            url_page = url
        # По каждой странице определяем параметры товара
        response = requests.get(url = url_page, headers = header).text
        soup = BeautifulSoup(response, 'html.parser')
        
        
        products = soup.find('div', class_="wrap_list_prod").find('div', class_="row").find_all('div', class_="col-lg-3 col-sm-6 list_bl_pr")
        for product in products:            
            # Находим адрес товара
            url_product = product.find('div', class_="blocks_product").find('div', class_="blocks_product_fix_w").find('a').get('href')
            url_product = f'https://store77.net{url_product}'            
            response = requests.get(url = url_product, headers = header).text
            soup = BeautifulSoup(response, 'html.parser')          
            
            # Находим наименование товара
            name_value = soup.find('h1', class_="title_card_product").text.replace('"','')            
            print(name_value)            
        
            # Находим цену товара
            price_value = soup.find('p', class_="price_title_product").text.replace('\n','').replace('Р','').split(' ')
            
            k = 0
            k_max = len(price_value)
            while k < k_max:
                k_max = len(price_value)
                        
                if price_value[k] == '':
                    del price_value[k]
                    k = 0
                    k_max = len(price_value)
                else:
                    k += 1
            if len(price_value) == 2:                
                price_value = int(f'{price_value[0]}{price_value[1]}')
                
            else:
                price_value = int(price_value[0])
            price_value = int(price_value*1.02)            
                  
            # Находим размер памяти
            try:
                memory_value = soup.find('a', class_="cpinfo_link active").text               
                
            except:
                memory_value = ''           
            
            # Находим цвет товара
            try:
                color_value = soup.find('span', class_="no_bor-r active").get('data-prop').split(':')
                color_value = color_value[2].replace('}','')
                color_value = colors.get(color_value)      
               
            except:
                color_value = ''
            
            # Определяем наличие товара
            availability = soup.find('div', class_="card_product_payment").find_all('p', class_="cpp_block_p")[0].text.replace('\n','').replace(' ','').split(':')
            
            availability = availability[1]

            # Находим описание товара
            try:
                description = str(soup.find('div', class_="wrap_descr_b")).partition('\n')[2]
            except:
                pass
            #print(description)
            # Находим характеристики товара
            char_dict = {}
            try:
                blocks = soup.find('div', class_="pages_card__content").find_all('div', class_="card_bgsection")[1].find('div', class_="card_bgsection__content").find('div', class_="tab-content").find_all('div')
            except:
                try:
                    blocks = soup.find('div', class_="pages_card__content").find_all('div', class_="card_bgsection")[0].find('div', class_="card_bgsection__content").find('div', class_="tab-content").find_all('div')
                except:
                    pass
            try:
                for block in blocks:
                    char_blocks = block.find_all('table', class_="tabs_table")
                    for char_block in char_blocks:
                        try:
                            chars = char_block.find('tbody').find_all('tr')
                        except:
                            pass
                        for char in chars:
                            try:                            
                                char_text = char.text.replace('\t','').replace('\r','').split('\n')
                            except:
                                pass
                        
                            l = 0
                            l_max = len(char_text)
                            while l < l_max:
                                l_max = len(char_text)
                        
                                if char_text[l] == '':
                                    del char_text[l]
                                    l = 0
                                    l_max = len(char_text)
                                else:
                                        l += 1
                        
                            try:
                                
                                char_text[0] = char_text[0].replace('"','')
                                s = char_text[0]
                                if s[0] == ' ':
                                    s = s[1:]
                                char_text[0] = s    
                                char_text[0] = char_text[0].replace(' ','_')
                                char_text[1] = char_text[1].replace('"','')
                                s = char_text[1]
                                if s[0] == ' ':
                                    s = s[1:]
                                char_text[1] = s    
                                new_word = ''
                                for letter in char_text[0]:
                                    if letter in dict_translate:
                                        new_letter = dict_translate.get(letter)
                                    else:
                                        new_letter = letter
                                    new_word += new_letter
                                
                                char_text[0] = new_word
                                char_text[0] = f'{char_text[0]}'.replace('\xa0','').replace('-','_').replace(')','').replace('(','').replace('/','').replace('‑','_').replace(':','')
                                char_text[1] = f'{char_text[1]}'
                                #print(char_text)
                                #print(char_text[1])
                                
                                char_dict[char_text[0]]=char_text[1]                           
                            
                            except:
                                pass
                            
            
            except:
                  pass                   
            print('')            
   
            try:
                prop = json.dumps(char_dict,ensure_ascii=False)
            
            except:
                prop = 'None'
            
            # Находим адреса фотографий

            datas = soup.find('div',class_ = 'swiper-wrapper').find_all('a')#картинка
            photo_1 = datas[0].get('style').partition('background-image: url(''')[2].partition(''');''')[0].replace("'",'')
            
            
            dicte = {}
            for i in range(1,len(datas)):
                dicte[f'img_{i}'] = datas[i].get('style').partition('background-image: url(''')[2].partition(''');''')[0].replace("'",'')
            res = json.dumps(dicte)
            # Проверяем наличие товара в базе данных и записываем изменения
                
            with connection.cursor() as cursor:
                if var_tuple == 1:
                    ins = f'''CREATE TABLE IF NOT EXISTS {table} (
                                    id int AUTO_INCREMENT primary key NOT NULL,
                                    name VARCHAR(200),
                                    price int,
                                    memory VARCHAR(200),
                                    color VARCHAR(300),
                                    properties JSON,
                                    availability VARCHAR(3000),
                                    description VARCHAR(10000),
                                    photo_1 VARCHAR(300),
                                    photo_all JSON
                            );'''           
                    cursor.execute(ins)  
                    connection.commit()
                else:
                    ins = f'''CREATE TABLE IF NOT EXISTS {table} (
                                    id int AUTO_INCREMENT primary key NOT NULL,
                                    name VARCHAR(200),
                                    price int,
                                    color VARCHAR(300),
                                    properties JSON,
                                    subcategory VARCHAR(300),
                                    availability VARCHAR(3000),
                                    description VARCHAR(10000),
                                    photo_1 VARCHAR(300),
                                    photo_all JSON
                            );'''           
                    cursor.execute(ins)  
                    connection.commit()
                select_all_rows = fr'''SELECT * FROM {table}'''
                cursor.execute(select_all_rows)
                rows = cursor.fetchall()
                index = 0
                for row in rows:
                    
                    if name_value == row.get('name'):
                        index = 1
                        line = row
                                                
                if index == 0:
                    if var_tuple == 1:
                        data_tuple = (table, name_value, price_value, memory_value, color_value, prop, availability, description, photo_1, res)
                        #print(data_tuple[0])   
                        
                        insert_query = fr'''INSERT INTO {data_tuple[0]}(name, price, memory, color, properties, availability, description, photo_1, photo_all) VALUES ('{data_tuple[1]}',{data_tuple[2]},'{data_tuple[3]}','{data_tuple[4]}','{data_tuple[5]}','{data_tuple[6]}','{data_tuple[7]}','{data_tuple[8]}','{data_tuple[9]}')'''.replace('\\','')
                        #print(insert_query)
                    else:    
                        data_tuple = (table, name_value, price_value, color_value, prop, subcategory, availability, description, photo_1, res)
                        #print(data_tuple[0])
                        
                        insert_query = f'''INSERT INTO {data_tuple[0]}(name, price, color, properties, subcategory, availability, description, photo_1, photo_all) VALUES ('{data_tuple[1]}',{data_tuple[2]},'{data_tuple[3]}','{data_tuple[4]}','{data_tuple[5]}','{data_tuple[6]}','{data_tuple[7]}','{data_tuple[8]}','{data_tuple[9]}')'''                  
                    cursor.execute(insert_query)
                    connection.commit()
                else:
                    if price_value != line.get('price'):
                        
                    
                        update_query_price = fr'''Update {table} set price = {price_value} where name = "{name_value}"'''
                        cursor.execute(update_query_price)
                        connection.commit()
                    if availability != line.get('availability'):
                        
                        print(table)
                        update_query_availability = fr'''Update {table} set availability = "{availability}" where name = "{name_value}"'''
                        cursor.execute(update_query_availability)
                        connection.commit()
                        
                                              
    
        j += 1
        print(j,'ooo')
    
while True:
    connection = pymysql.connect(host = 'localhost', user = "u2526134_wp500", password =  'd40c4MX84o0yIC16', database = 'u2526134_wp500', cursorclass = pymysql.cursors.DictCursor)
    file = open("links.txt", "r")
    while True:
        link = file.readline().replace("\n", "").split(' ')
        print(link)
        if link == ['']:
            break
        
        url = link[0]
        table = link[1]
        var_tuple = int(link[2])
        try:
            subcategory = link[3]
        except:
            pass
        
        
        main(url)
        
    file.close()
    connection.close()
    time.sleep(259200) 
